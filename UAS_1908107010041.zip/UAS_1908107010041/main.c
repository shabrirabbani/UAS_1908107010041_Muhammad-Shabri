#include <stdio.h>
#include <stdlib.h>
#include<string.h>

typedef struct{
    char kdbus[10];
    char nama[30];
    char asal[20];
    char tujuan[20];
}bus;

bus tambah[255], cek[255], cari[255]; 
char buff[255];

void login();
void main_menu();
void show_file();
void search_data();
void input_data();
void delete_data();
void edit_data();

int main(){
    login();
}

void login(){
    char user[20], pass[20];

    printf("====== SELAMAT DATANG ======\n");
    printf("LOGIN :\n");
    printf("username : ");
    scanf("%s",user);
    printf("password : ");
    scanf("%s",pass);
    if(strcmp(user,"admin")==0){
        if(strcmp(pass,"root")==0){
            printf("\nlogin berhasil\n");
        }else{
            printf("username atau password salah\n");
            login();
        }
        
    }   
    main_menu();
}

void main_menu(){
    int pilihan;
    printf("====== SELAMAT DATANG ADMIN ======\n");
    printf("MENU:\n");
    printf("1. tampilkan data bus\n");
    printf("2. cari data bus\n");
    printf("3. tambah data bus\n");
    printf("4. hapus data bus\n");
    printf("5. ubah data bus\n");
    printf("6. keluar\n\n");
    printf("pilihan : ");
    scanf("%d", &pilihan);

    switch(pilihan){
        case 1:
        show_file();
        break;
        case 2:
        search_data();
        break; 
        case 3:
        input_data();
        break;
        case 4:
        delete_data();
        break;
        case 5:
        edit_data();
        break;
        case 6:
        return;
    default:
    printf("menu tidak ada, silahkan ulang\n");
    main_menu();
    }


}

void show_file(){
    FILE *show;

    show = fopen("data/data.txt","r");
    while(fgets(buff, sizeof(buff), show)){
        printf("%s", buff);
    }

    fclose(show);
    main_menu();
    
}

void search_data(){

}

void input_data(){
    
FILE *fp, *fp1;
int jumlahdata=0;

fp=fopen("data/data.txt", "a");

fp1=fopen("data/data.txt", "a");
while (fscanf(fp1, "%[^\n], %[^\n], %[^\n], %[^\n]\n", &tambah[jumlahdata].kdbus, &tambah[jumlahdata].nama, &tambah[jumlahdata].asal, &tambah[jumlahdata].tujuan)!=EOF){
}


fclose(fp1);

printf("kdbus\t: ");
scanf(" %[^\n]s", tambah[jumlahdata].kdbus);
printf("nama\t: ");
scanf("%s", tambah[jumlahdata].nama);
printf("asal\t: ");
scanf(" %[^\n]s", tambah[jumlahdata].asal);
printf("tujuan\t: ");
scanf(" %[^\n]s", tambah[jumlahdata].tujuan);
fprintf(fp, "\n%s, %s, %s, %s\n", tambah[jumlahdata].kdbus, tambah[jumlahdata].nama, tambah[jumlahdata].asal, tambah[jumlahdata].tujuan);

fclose(fp);

printf("\nData Berhasil Ditambahkan\n");

main_menu();

}

void delete_data(){
    
}

void edit_data(){

}